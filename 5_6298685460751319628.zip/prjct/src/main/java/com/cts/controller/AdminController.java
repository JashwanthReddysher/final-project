package com.cts.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.util.ObjectUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cts.dao.AdminDao;
import com.cts.model.Admin;



@Controller
public class AdminController {
	@Autowired
	private AdminDao adminDao;


	@GetMapping("/admin")
	public String viewAdminpage() {
		return "admin";
	}
	
	
	// displays registration form
	@GetMapping("/aregister")
	public String viewCustomerRegister(Model model) {
		Admin admin=new Admin();
		model.addAttribute("admin",admin);
		return "adminRegister";
	}
	
	// validation and registration
	@PostMapping("/adminRegister")
	public String addVendor(@Valid @ModelAttribute("admin") Admin admin,BindingResult result,ModelMap map) {
		if(result.hasErrors()) {
			return "adminRegister";
		}
		
		adminDao.save(admin);
		
		return "adminRegisterSuccess";		
	}
	
	// display login form
	@GetMapping("/adminLogin")
	public String customerLogin() {
		
		return "adminLogin";
	}
	
	// login
	@PostMapping("/adminAuthentication")
	public String loginAuthentication(@RequestParam("username") String username,
			@RequestParam("password") String password,HttpSession session,Model model,HttpServletRequest request) {
	     Admin correct=adminDao.findByUsernameAndPassword(username,password);
	     if (!(ObjectUtils.isEmpty(correct))) {
	    	session.setAttribute("username", username);
	    	//System.out.println(session.getAttribute("username"));
	    	request.setAttribute("mode", "MODE_HOME");
	    	return "admin";
	     }
	     else {
	    	 System.out.println("false");
	    	   model.addAttribute("msg", "Invalid Login Credentials");
	    		return "adminLogin";
	     }
		
	}
	
	// logout
	@GetMapping("/adminLogout")
	public String logout(HttpSession session) {
		System.out.println(session.getAttribute("username"));
		session.removeAttribute("username");
		System.out.println(session.getAttribute("username"));
		return "redirect:/";
	}
}