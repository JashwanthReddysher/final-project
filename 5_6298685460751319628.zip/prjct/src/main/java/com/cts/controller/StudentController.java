package com.cts.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.util.ObjectUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;


import com.cts.dao.StudentDao;
import com.cts.model.Student;




@Controller
public class StudentController {
	@Autowired
	private StudentDao studentDao;


	@GetMapping("/student")
	public String viewAdminpage() {
		return "student";
	}
	
	
	// displays registration form
	@GetMapping("/sregister")
	public String viewStudentRegister(Model model) {
		Student student=new Student();
		model.addAttribute("student",student);
		return "studentRegister";
	}
	
	// validation and registration
	@PostMapping("/studentRegister")
	public String addVendor(@Valid @ModelAttribute("student") Student student,BindingResult result,ModelMap map) {
		if(result.hasErrors()) {
			return "studentRegister";
		}
		
		studentDao.save(student);
		
		return "studentRegisterSuccess";		
	}
	
	// display login form
	@GetMapping("/studentLogin")
	public String studentLogin() {
		
		return "studentLogin";
	}
	
	// login
	@PostMapping("/studentAuthentication")
	public String loginAuthentication(@RequestParam("username") String username,
			@RequestParam("password") String password,HttpSession session,Model model,HttpServletRequest request) {
	     Student correct=studentDao.findByUsernameAndPassword(username,password);
	     if (!(ObjectUtils.isEmpty(correct))) {
	    	session.setAttribute("username", username);
	    	//System.out.println(session.getAttribute("username"));
	    	request.setAttribute("mode", "MODE_HOME");
	    	return "student";
	     }
	     else {
	    	 System.out.println("false");
	    	   model.addAttribute("msg", "Invalid Login Credentials");
	    		return "studentLogin";
	     }
		
	}
	
	// logout
	@GetMapping("/studentLogout")
	public String logout(HttpSession session) {
		System.out.println(session.getAttribute("username"));
		session.removeAttribute("username");
		System.out.println(session.getAttribute("username"));
		return "redirect:/";
	}
}