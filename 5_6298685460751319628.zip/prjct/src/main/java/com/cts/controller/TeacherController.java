package com.cts.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.util.ObjectUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cts.dao.AdminDao;
import com.cts.dao.TeacherDao;
import com.cts.model.Admin;
import com.cts.model.Teacher;



@Controller
public class TeacherController {
	@Autowired
	private TeacherDao teacherDao;


	@GetMapping("/teacher")
	public String viewAdminpage() {
		return "teacher";
	}
	
	
	// displays registration form
	@GetMapping("/tregister")
	public String viewCustomerRegister(Model model) {
	Teacher teacher=new Teacher();
		model.addAttribute("teacher",teacher);
		return "teacherRegister";
	}
	
	// validation and registration
	@PostMapping("/teacherRegister")
	public String addVendor(@Valid @ModelAttribute("teacher") Teacher teacher,BindingResult result,ModelMap map) {
		if(result.hasErrors()) {
			return "teacherRegister";
		}
		
		teacherDao.save(teacher);
		
		return "teacherRegisterSuccess";		
	}
	
	// display login form
	@GetMapping("/teacherLogin")
	public String customerLogin() {
		
		return "teacherLogin";
	}
	
	// login
	@PostMapping("/teacherAuthentication")
	public String loginAuthentication(@RequestParam("username") String username,
			@RequestParam("password") String password,HttpSession session,Model model,HttpServletRequest request) {
	    Teacher correct=teacherDao.findByUsernameAndPassword(username,password);
	     if (!(ObjectUtils.isEmpty(correct))) {
	    	session.setAttribute("username", username);
	    	//System.out.println(session.getAttribute("username"));
	    	request.setAttribute("mode", "MODE_HOME");
	    	return "teacher";
	     }
	     else {
	    	 System.out.println("false");
	    	   model.addAttribute("msg", "Invalid Login Credentials");
	    		return "adminLogin";
	     }
		
	}
	
	// logout
	@GetMapping("/teacherLogout")
	public String logout(HttpSession session) {
		System.out.println(session.getAttribute("username"));
		session.removeAttribute("username");
		System.out.println(session.getAttribute("username"));
		return "redirect:/";
	}
}