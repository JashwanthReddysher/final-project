package com.cts.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

@Entity
public class Teacher {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	@NotBlank(message = "First Name should not be empty")
	private String firstname;
	@NotBlank(message = "Last Name shold not be empty")
	private String lastname;
	@NotBlank(message = "Date of birth should not be empty")
	private String dob;
	@NotEmpty(message = "Gender should be specitfied")
	private String gender;
	@NotNull(message = "Contact number should not be empty")
	@Pattern(regexp = "(^$|[0-9]{10})", message = "Contact number should be 10 digits")
	private String contactno;
	@NotBlank(message = "Email should not be empty")
	private String email;
	@NotBlank(message = "Username should not be empty")
	private String username;
	@NotBlank(message = "Password should not be empty")
	private String password;
	@Lob
	private byte[] picture;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getContactno() {
		return contactno;
	}
	public void setContactno(String contactno) {
		this.contactno = contactno;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public byte[] getPicture() {
		return picture;
	}
	public void setPicture(byte[] picture) {
		this.picture = picture;
	}
	public Teacher(Long id, @NotBlank(message = "First Name should not be empty") String firstname,
			@NotBlank(message = "Last Name shold not be empty") String lastname,
			@NotBlank(message = "Date of birth should not be empty") String dob,
			@NotEmpty(message = "Gender should be specitfied") String gender,
			@NotNull(message = "Contact number should not be empty") @Pattern(regexp = "(^$|[0-9]{10})", message = "Contact number should be 10 digits") String contactno,
			@NotBlank(message = "Email should not be empty") String email,
			@NotBlank(message = "Username should not be empty") String username,
			@NotBlank(message = "Password should not be empty") String password, byte[] picture) {
		super();
		this.id = id;
		this.firstname = firstname;
		this.lastname = lastname;
		this.dob = dob;
		this.gender = gender;
		this.contactno = contactno;
		this.email = email;
		this.username = username;
		this.password = password;
		this.picture = picture;
	}
	public Teacher() {
		super();
	}
	
	




}